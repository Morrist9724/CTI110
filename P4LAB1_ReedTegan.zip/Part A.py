# Tegan Reed
# 11/2/2025
# P4LAB1 Part A
# Drawing a square and a triangle using turtle graphics
import turtle

wn = turtle.Screen()
wn.bgcolor("lightblue")

t = turtle.Turtle()
t.pensize(3)
t.color("darkblue")

for i in range(4):
    t.forward(100)
    t.right(90)

t.penup()
t.goto(-50, -50)
t.pendown()

sides = 0
while sides < 3:
    t.forward(100)
    t.left(120)
    sides += 1

wn.mainloop()
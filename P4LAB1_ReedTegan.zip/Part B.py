# Tegan Reed
# 11/2/2025
# P4Lab1 Part B
# Drawing my intials using turtle graphics

import turtle

wn = turtle.Screen()
wn.bgcolor("white")

t = turtle.Turtle()
t.pensize(5)
t.color("darkgreen")

t.penup()
t.goto(-150, 100)
t.pendown()

for i in range(2):
    t.forward(100)
    t.penup()
    t.backward(50)
    t.right(90)
    t.pendown()

t.forward(100)

t.penup()
t.goto(50, 0)
t.setheading(90)
t.pendown()

t.forward(100)

t.right(90)
t.circle(-25, 180)

t.penup()
t.goto(50, 50)
t.setheading(-45)
t.pendown()

count = 0
while count < 1:
    t.forward(70)
    count += 1

t.hideturtle()
wn.mainloop()